-- SQLite
CREATE TABLE datauser(id integer primary key asc, FIO text, number integer unique, position text, department text, address text, director text)
-- CREATE TABLE user(id integer primary key asc, telegram_id integer unique, state text)


-- SQLite

--INSERT INTO datauser (FIO, number, position, department, address, director) VALUES ('Асатуллина Эльвира Раульевна1', '14605717f', 'Ведущий экономист', 'Филиал АО КИС «Исток» - ЮУС/Отдел подготовки производства', 'г. Озерск, Промышленная ул., 18', 'Исаев Р.Х.');
--INSERT INTO datauser (FIO, number, position, department, address, director) VALUES ('1', 'Асатуллина Эльвира Раульевна', '14605717', 'Ведущий экономист', 'Филиал АО КИС «Исток» - ЮУС/Отдел подготовки производства', 'г. Озерск, Промышленная ул., 18', 'Исаев Р.Х.');
--INSERT INTO datauser (FIO, number, position, department, address, director) VALUES ('2', 'Хлызов Евгений Александрович', '14605714', 'Начальник цеха', 'Филиал АО КИС «Исток» - ЮУС/Отдел подготовки производства', 'г. Озерск, Промышленная ул., 18', 'Исаев Р.Х.');
--INSERT INTO datauser (FIO, number, position, department, address, director) VALUES ('3', '11111111', '22222', '33333', '4444', '555555', '6666666');

--INSERT INTO datauser (FIO, number, position, departament, address, director) VALUES ('Асатуллина Эльвира Раульевна', '14605717', 'Ведущий экономист', 'Филиал АО КИС «Исток» - ЮУС/Отдел подготовки производства', 'г. Озерск, Промышленная ул., 18', 'Исаев Р.Х.');
--INSERT INTO datauser (FIO, number, position, departament, address, director) VALUES ('Хлызов Евгений Александрович', '14605714', 'Начальник цеха', 'Филиал АО КИС «Исток» - ЮУС/Отдел подготовки производства', 'г. Озерск, Промышленная ул., 18', 'Исаев Р.Х.');
--INSERT INTO datauser (FIO, number, position, departament, address, director) VALUES ('11111111', '22222', '33333', '4444', '555555', '6666666');

DELETE FROM datauser WHERE id=7
-- SQLite
select * From datauser;
